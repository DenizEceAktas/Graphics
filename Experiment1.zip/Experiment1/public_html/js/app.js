"use strict";
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
const pi = 3.1415;
var verticesData;
const angle = 2*pi/120;
const NumVertices = 24;
var  vPositions = [];
var  vColors = [];
const positions = [
    new point4( 0.0, 0.0,  0.0, 1.0 ),
    new point4( -1.0,  0.0,  0.0, 1.0 ),
    new point4(  0.0,  -1.0,  0.0, 1.0 ),
    new point4(  1.0, 0.0,  0.0, 1.0 ),
    new point4( 0.0, 1.0, 0.0, 1.0 ),
    new point4( -2.0,  2.0, 0.0, 1.0 ),
    new point4(  -2.0,  -2.0, 0.0, 1.0 ),
    new point4(  2.0, -2.0, 0.0, 1.0 ),
    new point4(  2.0, 2.0, 0.0, 1.0 )
];
const colors = [
   // new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    new color4( 0.5, 0.5, 0.5, 1.0 )
];
var Index = 0;  // global variable indexing into VBO arrays

//////////////////////////////////////////

var  cvPositions = [];
var  cvColors = [];
const Cirpositions = [
    new point4( 0.0, 0.0,  0.0, 1.0 ),
    new point4( -1.0,  0.0,  0.0, 1.0 ),
    new point4(  0.0,  -1.0,  0.0, 1.0 ),
    new point4(  1.0, 0.0,  0.0, 1.0 ),
    new point4( 0.0, 1.0, 0.0, 1.0 )
];
const Circolors = [
   // new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    //new color4( 0.5, 0.5, 0.5, 1.0 ),
    new color4( 1.0,1.0,0.0,1.0 )
];
var Index = 0;  // global variable indexing into VBO arrays

main();

function main() {
    const canvas = document.querySelector("#glCanvas");
    const  gl = canvas.getContext("webgl2");
    
    if(!gl) {
        alert("Unable to initialize WebGL. Your browser or machine may not support it.");
        return;
    }
    colorcube();
    
    var positionArray = [];
    for(var i = 0; i < NumVertices; i++) {
        positionArray = positionArray.concat(vPositions[i].elements());
    }
    var colorArray = [];
    for(var i = 0; i < NumVertices; i++) {
        colorArray = colorArray.concat(vColors[i].elements());
    }
    
    gl.clearColor(1.0,1.0,0.0,1.0);
    gl.clearDepth(1.0);                 
    gl.enable(gl.DEPTH_TEST);           
    gl.depthFunc(gl.LEQUAL);            

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    
    const numOfComponents = 4;
    const type = gl.FLOAT;
    const normalize = false;
    const stride = 0;
    const offset = 0;
    
    var program = initShaderProgram(gl, vShader, fShader);
    const buffer = initBuffers(gl, positionArray, colorArray);
    
    
    gl.useProgram(program);
    
    gl.uniformMatrix4fv(gl.getUniformLocation(program, "u_matrix"), false, matrix);
    
    gl.enableVertexAttribArray(gl.getAttribLocation(program, "a_position"));
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer.position);
    gl.vertexAttribPointer(gl.getAttribLocation(program, "a_position"), numOfComponents, type, normalize, stride, offset);
    
    gl.enableVertexAttribArray(gl.getAttribLocation(program, "a_color"));
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer.color);
    gl.vertexAttribPointer(gl.getAttribLocation(program, "a_color"), numOfComponents, type, normalize, stride, offset);
    
    gl.drawArrays(gl.TRIANGLES, offset, NumVertices);
    //gl.useProgram(program);
    
    ///////////////////////////////////////
    //circles(0.0, 0.0, 0.0, 0.5);
    circles();
   var positionArrays = [];
    for(var i = 0; i < NumVertices; i++) {
        positionArrays = positionArrays.concat(cvPositions[i].elements());
    }
    var colorArrays = [];
    for(var i = 0; i < NumVertices; i++) {
        colorArrays = colorArrays.concat(cvColors[i].elements());
    }
    
     var cprogram = initShaderProgram(gl, vShader, fShader);
    const cbuffer = initBuffers(gl, positionArrays, colorArrays);
    
    
    gl.useProgram(cprogram);
    
    gl.uniformMatrix4fv(gl.getUniformLocation(cprogram, "u_matrix"), false, matrix);
    
    gl.enableVertexAttribArray(gl.getAttribLocation(cprogram, "a_position"));
    gl.bindBuffer(gl.ARRAY_BUFFER, cbuffer.position);
    gl.vertexAttribPointer(gl.getAttribLocation(cprogram, "a_position"), numOfComponents, type, normalize, stride, offset);
    
    gl.enableVertexAttribArray(gl.getAttribLocation(cprogram, "a_color"));
    gl.bindBuffer(gl.ARRAY_BUFFER, cbuffer.color);
    gl.vertexAttribPointer(gl.getAttribLocation(cprogram, "a_color"), numOfComponents, type, normalize, stride, offset);
    
    gl.drawArrays(gl.TRIANGLES, offset, NumVertices);
    //gl.drawArrays( gl.TRIANGLE_FAN, 0, verticesData.length/2 );
}
  
function colorcube()
{
    quad( 0, 4, 5, 1 );
    quad( 0, 1, 6, 2 );
    quad( 0, 2, 7, 3 );
    quad( 0, 3, 8, 4 );
}

function quad(a, b, c, d )
{
    vColors[Index] = colors[0]; vPositions[Index] = positions[a]; Index++;
    vColors[Index] = colors[0]; vPositions[Index] = positions[b]; Index++;
    vColors[Index] = colors[0]; vPositions[Index] = positions[c]; Index++;
    vColors[Index] = colors[0]; vPositions[Index] = positions[a]; Index++;
    vColors[Index] = colors[0]; vPositions[Index] = positions[c]; Index++;
    vColors[Index] = colors[0]; vPositions[Index] = positions[d]; Index++;
}

function circle(a,b,c,d){
    
    cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[a]; Index++;
    cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[b]; Index++;
    cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[c]; Index++;
    cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[a]; Index++;
    cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[c]; Index++;
   cvColors[Index] = Circolors[0]; cvPositions[Index] = Cirpositions[d]; Index++;
    
}

function circles(){
    
    circle( 0, 4, 5, 1 );
    circle( 0, 1, 6, 2 );
    circle( 0, 2, 7, 3 );
    circle( 0, 3, 8, 4 );
    
    /*const angles = angle;
    
    var vertices = [x,y,z];
    
    for(var i = 1; i < angles; i++){
        
        vertices.push((x + r * Math.cos(i * pi*2 / (angle/2))));
        vertices.push((y + r * Math.cos(i * pi*2 / (angle/2))));
        
    }*/
    
    
    /*var xCenterOfCircle = x;
    var yCenterOfCircle = y;
    var centerOfCircle = vec2(x, y);
    var anglePerFan = (2*Math.PI) / 72;
    verticesData = [centerOfCircle];

    for(var i = 0; i <= 72; i++)
    {
        var index = 2 * i + 2;
        var angle = anglePerFan * (i+1);
        var xCoordinate = xCenterOfCircle + Math.cos(angle) * r;
        var yCoordinate = yCenterOfCircle + Math.sin(angle) * r;
        var point = vec2(xCoordinate, yCoordinate);
        verticesData.push(point);
   }*/
    
}